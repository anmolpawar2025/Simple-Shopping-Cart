import React, { useState } from 'react'

export default function Cart({ cartItems, total, setQuantity, checkout }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="cart">
      <button onClick={() => setOpen(true)}>Cart ({cartItems.reduce((s,i)=>s+i.quantity,0)})</button>

      {open && (
        <div className="modal">
          <div className="modal-content">
            <button className="close" onClick={() => setOpen(false)}>Close</button>
            <h2>Your Cart</h2>
            {cartItems.length === 0 ? <p>Cart is empty</p> : (
              <>
                <div className="cart-list">
                  {cartItems.map(item => (
                    <div key={item.id} className="cart-row">
                      <img src={item.imageUrl} alt={item.name} width={60} />
                      <div className="cart-name">{item.name}</div>
                      <div>₹{item.price}</div>
                      <div>
                        <input
                          type="number"
                          min="0"
                          value={item.quantity}
                          onChange={(e) => setQuantity(item.id, Number(e.target.value))}
                        />
                      </div>
                      <div>₹{item.subtotal}</div>
                    </div>
                  ))}
                </div>
                <h3>Total: ₹{total}</h3>
                <div className="cart-actions">
                  <button onClick={checkout}>Checkout</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
