import React, { useEffect, useState } from 'react'
import ProductList from './ProductList'
import Cart from './Cart'

export default function App() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [cart, setCart] = useState({})

  useEffect(() => {
    const saved = localStorage.getItem('cart')
    if (saved) setCart(JSON.parse(saved))
  }, [])

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart))
  }, [cart])

  useEffect(() => {
    fetch('http://localhost:4000/api/products')
      .then(r => r.json())
      .then(data => { setProducts(data); setLoading(false) })
      .catch(err => { console.error(err); setLoading(false) })
  }, [])

  const addToCart = (id) => setCart(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }))
  const setQuantity = (id, qty) => setCart(prev => {
    const copy = { ...prev }
    if (qty <= 0) delete copy[id]
    else copy[id] = qty
    return copy
  })
  const clearCart = () => setCart({})

  const cartItems = Object.entries(cart).map(([id, quantity]) => {
    const product = products.find(p => p.id === id) || { id, name: 'Unknown', price: 0, imageUrl: '' }
    return { ...product, quantity, subtotal: product.price * quantity }
  })
  const total = cartItems.reduce((s, i) => s + i.subtotal, 0)

  const checkout = async () => {
    if (cartItems.length === 0) { alert('Cart is empty'); return }
    try {
      const res = await fetch('http://localhost:4000/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: cartItems.map(i => ({ id: i.id, quantity: i.quantity })) })
      })
      const data = await res.json()
      if (data.success) {
        alert(`Order placed! Total: ₹${data.total}. Order ID: ${data.orderId}`)
        clearCart()
      } else {
        alert('Checkout failed')
      }
    } catch (err) {
      console.error(err)
      alert('Network error during checkout')
    }
  }

  return (
    <div className="app">
      <header className="header">
        <h1>Simple Shopping Cart</h1>
        <Cart cartItems={cartItems} total={total} setQuantity={setQuantity} checkout={checkout} />
      </header>
      <main>
        {loading ? <p>Loading products...</p> : <ProductList products={products} addToCart={addToCart} />}
      </main>
    </div>
  )
}
