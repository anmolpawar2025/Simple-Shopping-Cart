// server/index.js
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const products = [
  { id: 'p1', name: 'Blue T-Shirt', price: 399, imageUrl: 'https://picsum.photos/seed/p1/400/300' },
  { id: 'p2', name: 'Sneakers',     price: 2499, imageUrl: 'https://picsum.photos/seed/p2/400/300' },
  { id: 'p3', name: 'Cap',          price: 199, imageUrl: 'https://picsum.photos/seed/p3/400/300' },
  { id: 'p4', name: 'Backpack',     price: 1499, imageUrl: 'https://picsum.photos/seed/p4/400/300' },
  { id: 'p5', name: 'Sunglasses',   price: 799, imageUrl: 'https://picsum.photos/seed/p5/400/300' }
];

app.get('/api/products', (req, res) => {
  res.json(products);
});

app.post('/api/checkout', (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : [];
  const enriched = items.map(it => {
    const p = products.find(x => x.id === it.id) || { name: 'Unknown', price: 0 };
    const qty = Number(it.quantity) || 0;
    return { id: it.id, name: p.name, price: p.price, quantity: qty, subtotal: p.price * qty };
  });
  const total = enriched.reduce((s, i) => s + i.subtotal, 0);

  console.log('--- New Order ---');
  console.log({ order: enriched, total, time: new Date().toISOString() });
  console.log('-----------------');

  res.json({ success: true, orderId: String(Date.now()), total });
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 4000;
  app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
}
